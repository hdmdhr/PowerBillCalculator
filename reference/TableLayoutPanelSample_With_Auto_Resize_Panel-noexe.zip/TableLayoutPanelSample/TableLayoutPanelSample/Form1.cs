﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TableLayoutPanelSample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            label8.Visible=label9.Visible=label10.Visible=label11.Visible=checkBox1.Checked;
            textBox7.Visible = textBox8.Visible = textBox9.Visible = textBox10.Visible = checkBox1.Checked;
        }
    }
}
